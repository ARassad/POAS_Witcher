package prin366_2018.client.Settings;

import android.app.Activity;

/**
 * Created by Dryush on 15.02.2018.
 */

public class SettingsActivity extends Activity {

    private class AppSettings{

    }

}
