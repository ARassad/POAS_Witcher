package ServerExchange.ServerRequests;

/**
 * Created by Dryush on 15.02.2018.
 */

public class ServerException extends RuntimeException {
    ServerException(String mes){
        super(mes);
    }

}
